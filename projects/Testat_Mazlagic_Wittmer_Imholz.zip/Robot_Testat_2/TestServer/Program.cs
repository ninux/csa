﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace TestServer
{
    class Program
    {
        static void Main(string[] args)
        {
            DriveServer driveServer1 = new DriveServer();
            //Console.WriteLine("Welcome to C# on Windows Embedded Systems");
            //SimpleHttpServer SimpleHttpServer = new SimpleHttpServer();
        }
    }
}